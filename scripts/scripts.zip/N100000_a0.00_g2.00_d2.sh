#!/bin/bash
#SBATCH -J a0.0_g2.0_d2
#SBATCH --mail-user=junioralencar@fisica.ufc.br
#SBATCH --ntasks=1
#SBATCH --mail-type=ALL
x=0
n_samples=120
while [ $x -le $n_samples ]
do
	srun ../build/exe1 ../parms/N_100000_a0.00_g2.00_d2.json
	x=$(( $x + 1 ))
done